import React from 'react';
import { Link } from 'react-router-dom';
import { GamingList } from './MobileList';
import { Carousel } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

export const GamingPage = () => {
  return (
    <div className="row row-cols-1 row-cols-md-5 g-4">
      {
        GamingList.map((item, index) => (
          <div key={index} className="col">
            <Carousel>
              <Carousel.Item>
                <div className="card" style={{ width: "18rem" }}>
                  <img src={item.image} width={200} height={150} alt={item.image} />
                </div>

              </Carousel.Item>
              <Carousel.Item>
                <img src={item.image} width={200} height={150} alt="First slide" />
              </Carousel.Item>
              <Carousel.Item>
                <img src={item.image} width={200} height={150} alt="First slide" />
                
              </Carousel.Item>
            </Carousel>
              <div className="card-body">
                      <h5 className="card-title">{item.name}</h5>
                      <p className="card-text">{item.description}</p>
                      <Link to={`/gaming/${item.name.toLowerCase().replace(/\s+/g, '-')}/description`} className="btn btn-primary">
                        more info
                      </Link>
                  </div>
          </div>
        ))
      }
    </div>
  )
};
