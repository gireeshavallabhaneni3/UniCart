
import audioImage from './images/audio.jpeg';
import menFashionImage from './images/menfashion.jpeg';
import womenFashionImage from './images/womenfashion.jpeg';
import kidsWearImage from './images/kidswear.jpeg';
import kitchenImage from './images/kitchen.jpeg';
import beautyImage from './images/beauty.jpeg';
import furnitureImage from './images/furniture.jpeg';
import fitnessImage from './images/fitness.jpeg';
import booksImage from './images/books.jpeg';
import gamingImage from './images/gaming.jpeg';
import automobileImage from './images/automobile.jpeg';
import groceriesImage from './images/groceries.jpeg';
import petImage from './images/pet.jpeg';
import travelImage from './images/travel.jpeg';
import decorImage from './images/decor.jpeg';
import accessoriesImage from './images/accessories.jpeg';
import iphone14ProImage from './images/iphone14pro.jpeg';
import samsungImage from './images/s23ultra.jpeg';
import oneplusImage from './images/oneplus11.jpeg';
import googlepixel7proImage from './images/googlepixel7pro.jpeg';
import xiaomi13proImage from'./images/xiaomi13pro.jpeg';
import nothingphone1Image from'./images/nothingphone1.jpeg';
import asuszenbookImage from './images/asuszenbook.jpeg';
import asusvivobookImage from './images/asusvivobook.jpeg';
import lenovothinkpadImage from './images/lenovothinkpad.jpeg';
import dellinspironImage from './images/dellinspiron.jpeg';
import macbookairImage from './images/macbookair.jpeg';
import macbookproImage from './images/macbookpro.jpeg';
import hppavilionImage from './images/hp pavilion.jpeg';
import dellxpsImage from './images/dellxps.jpeg';
import refrigeratorImage from './images/refrigerator.jpeg';
import washingmachineImage from './images/washing machine.jpeg';
import microwaveImage from './images/ifbmicrowave.jpeg';
import dishwasherImage from './images/dishwasher.jpeg';
import lloydairconditionerImage from './images/lloydairconditioner.jpeg';
import vacuumcleanerImage from'./images/vacuumcleaner.jpeg';
import waterpurifierImage from './images/waterpurifier.jpeg';
import electrickettleImage from './images/electrickettle.jpeg';
import blenderImage from './images/blender.jpeg';
import toasterImage from './images/toaster.jpeg';
import samsungtvImage from './images/samsungtv.jpeg';
import lgtvImage from './images/lgtv.jpeg';
import sonytvImage from './images/sonytv.jpeg';
import tcltvImage from './images/tcltv.jpeg';
import hisensetvImage from './images/hisensetv.jpeg';
import viziotvImage from './images/viziotv.jpeg';
import panasonictvImage from './images/panasonictv.jpeg';
import xiaomitvImage from './images/xiaomitv.jpeg';
import oneplustvImage from './images/oneplustv.jpeg';
import realmetvImage from './images/realmetv.jpeg';




// import iphone14ProImage from './images/iphone14pro.jpeg';
// import samsungImage from './images/s23ultra.jpeg';
// import oneplusImage from './images/oneplus11.jpeg';
// import googlepixel7proImage from './images/googlepixel7pro.jpeg';
// import xiaomi13proImage from'./images/xiaomi13pro.jpeg';
// import nothingphone1Image from'./images/nothingphone1.jpeg';
// import asuszenbookImage from './images/asuszenbook.jpeg';
// import asusvivobookImage from './images/asusvivobook.jpeg';
// import lenovothinkpadImage from './images/lenovothinkpad.jpeg';
// import dellinspironImage from './images/dellinspiron.jpeg';
// import macbookairImage from './images/macbookair.jpeg';
// import macbookproImage from './images/macbookpro.jpeg';
// import hppavilionImage from './images/hp pavilion.jpeg';
// import dellxpsImage from './images/dellxps.jpeg';
// import refrigeratorImage from './images/refrigerator.jpeg';
// import washingmachineImage from './images/washing machine.jpeg';
// import microwaveImage from './images/ifbmicrowave.jpeg';
// import dishwasherImage from './images/dishwasher.jpeg';
// import lloydairconditionerImage from './images/lloydairconditioner.jpeg';
// import vacuumcleanerImage from'./images/vacuumcleaner.jpeg';
// import waterpurifierImage from './images/waterpurifier.jpeg';
// import electrickettleImage from './images/electrickettle.jpeg';
// import blenderImage from './images/blender.jpeg';
// import toasterImage from './images/toaster.jpeg';
// import samsungtvImage from './images/samsungtv.jpeg';
// import lgtvImage from './images/lgtv.jpeg';
// import sonytvImage from './images/sonytv.jpeg';
// import tcltvImage from './images/tcltv.jpeg';
// import hisensetvImage from './images/hisensetv.jpeg';
// import viziotvImage from './images/viziotv.jpeg';
// import panasonictvImage from './images/panasonictv.jpeg';
// import xiaomitvImage from './images/xiaomitv.jpeg';
// import oneplustvImage from './images/oneplustv.jpeg';
// import realmetvImage from './images/realmetv.jpeg';
// import audioImage from './images/audio.jpeg';
// import kitchenImage from './images/kitchen.jpeg';
// import kidsWearImage from './images/kidswear.jpeg';
// import beautyImage from './images/beauty.jpeg';
// import menFashionImage from './images/menfashion.jpeg';
// import womenFashionImage from './images/womenfashion.jpeg';
// import furnitureImage from './images/furniture.jpeg';
// import fitnessImage from './images/fitness.jpeg';
// import booksImage from './images/books.jpeg';
// import gamingImage from './images/gaming.jpeg';
// import automobileImage from './images/automobile.jpeg';
// import groceriesImage from './images/groceries.jpeg';
// import petImage from './images/pet.jpeg';
// import travelImage from './images/travel.jpeg';
// import decorImage from './images/decor.jpeg';
// import accessoriesImage from './images/accessories.jpeg';
import iphone14ProImage2 from './images/iphone14pro2.jpeg';
import iphone14ProImage3 from './images/iphone14pro3.jpeg';
import samsungImage2 from './images/s23ultra2.jpeg';
import samsungImage3 from './images/s23ultra3.jpeg';
import oneplusImage2 from './images/oneplus112.jpeg';
import oneplusImage3 from './images/oneplus113.jpeg';
import googlepixel7proImage2 from './images/googlepixel7pro2.jpeg';
import googlepixel7proImage3 from './images/googlepixel7pro3.jpeg';
import xiaomi13proImage2 from './images/xiaomi13pro2.jpeg';
import xiaomi13proImage3 from './images/xiaomi13pro3.jpeg';
import nothingphone1Image2 from './images/nothingphone12.jpeg';
import nothingphone1Image3 from './images/nothingphone13.jpeg';
import asuszenbookImage2 from './images/asuszenbook2.jpeg';
import asuszenbookImage3 from './images/asuszenbook3.jpeg';
import asusvivobookImage2 from './images/asusvivobook2.jpeg';
import asusvivobookImage3 from './images/asusvivobook3.jpeg';
import lenovothinkpadImage2 from './images/lenovothinkpad2.jpeg';
import lenovothinkpadImage3 from './images/lenovothinkpad3.jpeg';
import dellinspironImage2 from './images/dellinspiron2.jpeg';
import dellinspironImage3 from './images/dellinspiron3.jpeg';
import macbookairImage2 from './images/macbookair2.jpeg';
import macbookairImage3 from './images/macbookair3.jpeg';
import macbookproImage2 from './images/macbookpro2.jpeg';
import macbookproImage3 from './images/macbookpro3.jpeg';
import hppavilionImage2 from './images/hp pavilion2.jpeg';
import hppavilionImage3 from './images/hp pavilion3.jpeg';
import dellxpsImage2 from './images/dellxps2.jpeg';
import dellxpsImage3 from './images/dellxps3.jpeg';
import refrigeratorImage2 from './images/refrigerator2.jpeg';
import refrigeratorImage3 from './images/refrigerator3.jpeg';
import washingmachineImage2 from './images/washing machine2.jpeg';
import washingmachineImage3 from './images/washing machine3.jpeg';
import microwaveImage2 from './images/ifbmicrowave2.jpeg';
import microwaveImage3 from './images/ifbmicrowave3.jpeg';
import dishwasherImage2 from './images/dishwasher2.jpeg';
import dishwasherImage3 from './images/dishwasher3.jpeg';
import lloydairconditionerImage2 from './images/lloydairconditioner2.jpeg';
import lloydairconditionerImage3 from './images/lloydairconditioner3.jpeg';
import vacuumcleanerImage2 from './images/vacuumcleaner2.jpeg';
import vacuumcleanerImage3 from './images/vacuumcleaner3.jpeg';
import waterpurifierImage2 from './images/waterpurifier2.jpeg';
import waterpurifierImage3 from './images/waterpurifier3.jpeg';
import electrickettleImage2 from './images/electrickettle2.jpeg';
import electrickettleImage3 from './images/electrickettle3.jpeg';
import blenderImage2 from './images/blender2.jpeg';
import blenderImage3 from './images/blender3.jpeg';
import toasterImage2 from './images/toaster2.jpeg';
import toasterImage3 from './images/toaster3.jpeg';
import samsungtvImage2 from './images/samsungtv2.jpeg';
import samsungtvImage3 from './images/samsungtv3.jpeg';
import lgtvImage2 from './images/lgtv2.jpeg';
import lgtvImage3 from './images/lgtv3.jpeg';
import sonytvImage2 from './images/sonytv2.jpeg';
import sonytvImage3 from './images/sonytv3.jpeg';
import tcltvImage2 from './images/tcltv2.jpeg';
import tcltvImage3 from './images/tcltv3.jpeg';
import hisensetvImage2 from './images/hisensetv2.jpeg';
import hisensetvImage3 from './images/hisensetv3.jpeg';
import viziotvImage2 from './images/viziotv2.jpeg';
import viziotvImage3 from './images/viziotv3.jpeg';
import panasonictvImage2 from './images/panasonictv2.jpeg';
import panasonictvImage3 from './images/panasonictv3.jpeg';
import xiaomitvImage2 from './images/xiaomitv2.jpeg';
import xiaomitvImage3 from './images/xiaomitv3.jpeg';
import oneplustvImage2 from './images/oneplustv2.jpeg';
import oneplustvImage3 from './images/oneplustv3.jpeg';
import realmetvImage2 from './images/realmetv2.jpeg';
import realmetvImage3 from './images/realmetv3.jpeg';
import headPhonesImage1 from './images/headphones1.jpeg';
import headPhonesImage2 from './images/headphones2.jpeg';
import headPhonesImage3 from './images/headphones3.jpeg';
import earbudsImage1 from './images/earbuds1.jpeg';
import earbudsImage2 from './images/earbuds2.jpeg';
import earbudsImage3 from './images/earbuds3.jpeg';
import bluetoothspeakerImage1 from './images/bluetoothspeaker1.jpeg';
import bluetoothspeakerImage2 from './images/bluetoothspeaker2.jpeg';
import bluetoothspeakerImage3 from './images/bluetoothspeaker3.jpeg';
import soundbarImage1 from './images/soundbar1.jpeg';
import soundbarImage2 from './images/soundbar2.jpeg';
import soundbarImage3 from './images/soundbar3.jpeg';
import hometheatersystemImage1 from './images/hometheatersystem1.jpeg';
import hometheatersystemImage2 from './images/hometheatersystem2.jpeg';
import hometheatersystemImage3 from './images/hometheatersystem3.jpeg';
import formalshirtImage1 from './images/formalshirt1.jpeg';
import formalshirtImage2 from './images/formalshirt2.jpeg';
import formalshirtImage3 from './images/formalshirt3.jpeg';
import casualshirtImage1 from './images/casualshirt1.jpeg';
import casualshirtImage2 from './images/casualshirt2.jpeg';
import casualshirtImage3 from './images/casualshirt3.jpeg';
import blazerImage1 from './images/blazer1.jpeg';
import blazerImage2 from './images/blazer2.jpeg';
import blazerImage3 from './images/blazer3.jpeg';
import jeansImage1 from './images/jeans1.jpeg';
import jeansImage2 from './images/jeans2.jpeg';
import jeansImage3 from './images/jeans3.jpeg';
import sneakersImage1 from './images/sneakers1.jpeg';
import sneakersImage2 from './images/sneakers2.jpeg';
import sneakersImage3 from './images/sneakers3.jpeg';
import summerDressImage1 from './images/summerdress1.jpeg';
import summerDressImage2 from './images/summerdress2.jpeg';
import summerDressImage3 from './images/summerdress3.jpeg';
import eveningGown1 from './images/eveninggown1.jpeg';
import eveningGown2 from './images/eveninggown2.jpeg';
import eveningGown3 from './images/eveninggown3.jpeg';
import topsImage1 from './images/tops1.jpeg';
import topsImage2 from './images/tops2.jpeg';
import topsImage3 from './images/tops3.jpeg';
import skirtsImage1 from './images/skirts1.jpeg';
import skirtsImage2 from './images/skirts2.jpeg';
import skirtsImage3 from './images/skirts3.jpeg';
import handbagsImage1 from './images/handbags1.jpeg';
import handbagsImage2 from './images/handbags2.jpeg';
import handbagsImage3 from './images/handbags3.jpeg';
import boysdenimjacketImage1 from './images/boysdenimjacket1.jpeg';
import boysdenimjacketImage2 from './images/boysdenimjacket2.jpeg';
import boysdenimjacketImage3 from './images/boysdenimjacket3.jpeg';
import girlsPartywearImage1 from './images/girls partywear1.jpeg';
import girlsPartywearImage2 from './images/girls partywear2.jpeg';
import girlsPartywearImage3 from './images/girls partywear3.jpeg';
import toddlerRompersImage1 from './images/toddlerrompers1.jpeg';
import toddlerRompersImage2 from './images/toddlerrompers2.jpeg';
import toddlerRompersImage3 from './images/toddlerrompers3.jpeg';
import kidssportswearset1 from './images/kidssportswearset1.jpeg';
import kidssportswearset2 from './images/kidssportswearset2.jpeg';
import kidssportswearset3 from './images/kidssportswearset3.jpeg';
import kidsWinterCoatImage1 from './images/kidswintercoat1.jpeg';
import kidsWinterCoatImage2 from './images/kidswintercoat2.jpeg';
import kidsWinterCoatImage3 from './images/kidswintercoat3.jpeg';
import girlsleggingspack1 from './images/girlsleggingspack1.jpeg';
import girlsleggingspack2 from './images/girlsleggingspack2.jpeg';
import girlsleggingspack3 from './images/girlsleggingspack3.jpeg';
import lipstickSetImage1 from './images/lipstickset1.jpeg';
import lipstickSetImage2 from './images/lipstickset2.jpeg';
import lipstickSetImage3 from './images/lipstickset3.jpeg';
import faceSerumImage1 from './images/faceserum1.jpeg';
import faceSerumImage2 from './images/faceserum2.jpeg';
import faceSerumImage3 from './images/faceserum3.jpeg';
import mascaraImage1 from'./images/mascara1.jpeg';
import mascaraImage2 from'./images/mascara2.jpeg';
import mascaraImage3 from'./images/mascara3.jpeg';
import foundationImage1 from './images/foundation1.jpeg';
import foundationImage2 from './images/foundation2.jpeg';
import foundationImage3 from './images/foundation3.jpeg';
import facialcleanserImage1 from './images/facialcleanser1.jpeg';
import facialcleanserImage2 from './images/facialcleanser2.jpeg';
import facialcleanserImage3 from './images/facialcleanser3.jpeg';
import mixerImage1 from './images/mixer1.jpeg';
import mixerImage2 from './images/mixer2.jpeg';
import mixerImage3 from './images/mixer3.jpeg';
import nonStickCookwearSet1 from './images/nonstickcookwearset1.jpeg';
import nonStickCookwearSet2 from './images/nonstickcookwearset2.jpeg';
import nonStickCookwearSet3 from './images/nonstickcookwearset3.jpeg';
import airFryerImage1 from './images/airfryer1.jpeg';
import airFryerImage2 from './images/airfryer2.jpeg';
import airFryerImage3 from './images/airfryer3.jpeg';
import coffeeMakerImage1 from './images/coffeemaker1.jpeg';
import coffeeMakerImage2 from './images/coffeemaker2.jpeg';
import coffeeMakerImage3 from './images/coffeemaker3.jpeg';
import knifeSetImage1 from './images/knifeset1.jpeg';
import knifeSetImage2 from './images/knifeset2.jpeg';
import knifeSetImage3 from './images/knifeset3.jpeg';
import sofaImage1 from './images/sofa1.jpeg';
import sofaImage2 from './images/sofa2.jpeg';
import sofaImage3 from './images/sofa3.jpeg';
import diningTableImage1 from './images/diningtable1.jpeg';
import diningTableImage2 from './images/diningtable2.jpeg';
import diningTableImage3 from './images/diningtable3.jpeg';
import bedImage1 from './images/bed1.jpeg';
import bedImage2 from './images/bed2.jpeg';
import bedImage3 from './images/bed3.jpeg';
import coffeeTableImage1 from './images/coffeeTableI1.jpeg';
import coffeeTableImage2 from './images/coffeeTable2.jpeg';
import coffeeTableImage3 from './images/coffeeTable3.jpeg';
import bookshelfImage1 from './images/bookshelf1.jpeg';
import bookshelfImage2 from './images/bookshelf2.jpeg';
import bookshelfImage3 from './images/bookshelf3.jpeg';
import treadmillImage1 from './images/treadmill1.jpeg';
import treadmillImage2 from './images/treadmill2.jpeg';
import treadmillImage3 from './images/treadmill3.jpeg';
import dumbellssetImage1 from './images/dumbellsset1.jpeg';
import dumbellssetImage2 from './images/dumbellsset2.jpeg';
import dumbellssetImage3 from './images/dumbellsset3.jpeg';
import exercisebikeImage1 from './images/exercisebike1.jpeg';
import exercisebikeImage2 from './images/exercisebike2.jpeg';
import exercisebikeImage3 from './images/exercisebike3.jpeg';
import yogamatImage1 from './images/yogamat1.jpeg';
import yogamatImage2 from './images/yogamat2.jpeg';
import yogamatImage3 from './images/yogamat3.jpeg';
import resistancebandImage1 from './images/resistanceband1.jpeg';
import resistancebandImage2 from './images/resistanceband2.jpeg';
import resistancebandImage3 from './images/resistanceband3.jpeg';
import toKillaMockingbirdBookImage1 from './images/tokillamockingbirdbook1.jpeg';
import toKillaMockingbirdBookImage2 from './images/tokillamockingbirdbook2.jpeg';
import toKillaMockingbirdBookImage3 from './images/tokillamockingbirdbook3.jpeg';
import bookImage1 from './images/1984book1.jpeg';
import bookImage2 from './images/1984book2.jpeg';
import bookImage3 from './images/1984book3.png';
import prideandprejudiceImage1 from './images/prideandprejudiceImage1.jpeg';
import prideandprejudiceImage2 from './images/prideandprejudiceImage2.jpeg';
import prideandprejudiceImage3 from './images/prideandprejudiceImage3.jpeg';
import mobydickImage1 from './images/mobydick1.jpeg';
import mobydickImage2 from './images/mobydick2.jpeg';
import mobydickImage3 from './images/mobydick3.jpeg';





export const MobilesList = [
    {
      name: "iPhone 14 Pro",
      description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
      // image: iphone14ProImage,
      image1: iphone14ProImage,
      image2: iphone14ProImage2,
      image3: iphone14ProImage3,
      path: "/mobiles/iphone-14-pro"
    },
    {
      name: "Samsung Galaxy S23 Ultra",
      description: "High-performance Android phone with 200MP camera and S Pen.",
      image1: samsungImage,
      image2: samsungImage2,
      image3: samsungImage3,      
      path: "/mobiles/galaxy-s23-ultra"
    },
    {
      name: "OnePlus 11",
      description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
      image1: oneplusImage,
      image2: oneplusImage2,
      image3: oneplusImage3,      path: "/mobiles/oneplus-11"
    },
    {
      name: "Google Pixel 7 Pro",
      description: "Google's premium phone with best-in-class camera and AI features.",
      image1: googlepixel7proImage,
      image2: googlepixel7proImage2,
      image3: googlepixel7proImage3,      path: "/mobiles/pixel-7-pro"
    },
    {
      name: "Xiaomi 13 Pro",
      description: "Flagship killer with Leica camera system and ultra-fast charging.",
      image1: xiaomi13proImage,
      image2: xiaomi13proImage2,
      image3: xiaomi13proImage3,      path: "/mobiles/xiaomi-13-pro"
    },
    {
      name: "Nothing Phone (1)",
      description: "Unique transparent design with Glyph interface and clean OS.",
      image1: nothingphone1Image,
      image2: nothingphone1Image2,
      image3: nothingphone1Image3,      path: "/mobiles/nothing-phone-1"
    },
  
  ];
  

  export const LaptopsList = [
    {
        name: "Asus genbook",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: asuszenbookImage,
        image2: asuszenbookImage2,
        image3: asuszenbookImage3,
        path: "/laptops/asus-genbook"
      },
      {
        name: "Asus vivobook",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: asusvivobookImage,
        image2: asusvivobookImage2,
        image3: asusvivobookImage3,
        path: "/laptops/asus-vivobook"
      },
      {
        name: "Lenovo thinkpad",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: lenovothinkpadImage,
        image2: lenovothinkpadImage2,
        image3: lenovothinkpadImage3,
        path: "/laptops/oneplus-11"
      },
      {
        name: "Dell inspiron",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: dellinspironImage,
        image2: dellinspironImage2,
        image3: dellinspironImage3,
        path: "/laptops/pixel-7-pro"
      },
      {
        name: "macbook air",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: macbookairImage,
        image2: macbookairImage2,
        image3: macbookairImage3,
        path: "/laptops/xiaomi-13-pro"
      },
      {
        name: "macbook pro",
        description: "Unique transparent design with Glyph interface and clean OS.",
        image1: macbookproImage,
        image2: macbookproImage2,
        image3: macbookproImage3,
        path: "/laptops/nothing-phone-1"
      },
      {
        name: "hp pavilion",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: hppavilionImage,
        image2: hppavilionImage2,
        image3: hppavilionImage3,
        path: "/laptops/oneplus-11"
      },
      {
        name: "dell xps",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: dellxpsImage,
        image2: dellxpsImage2,
        image3: dellxpsImage3,
        path: "/laptops/pixel-7-pro"
      },
      
  ]

  
  export const AppliancesList = [
    {
        name: "refrigerator",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: refrigeratorImage,
        image2: refrigeratorImage2,
        image3: refrigeratorImage3,
        path: "/appliances/iphone-14-pro"
      },
      {
        name: "washing machine",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: washingmachineImage,
      image2: washingmachineImage2,
      image3: washingmachineImage3,
        path: "/appliances/galaxy-s23-ultra"
      },
      {
        name: "microwave",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: microwaveImage,
        image2: microwaveImage2,
        image3: microwaveImage3,
        path: "/appliances/oneplus-11"
      },
      {
        name: "dishwasher",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: dishwasherImage,
      image2: dishwasherImage2,
      image3: dishwasherImage3,
        path: "/appliances/pixel-7-pro"
      },
      {
        name: "air conditioner",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: lloydairconditionerImage,
        image2: lloydairconditionerImage2,
        image3: lloydairconditionerImage3,
        path: "/appliances/xiaomi-13-pro"
      },
      {
        name: "vacuum cleaner",
        description: "Unique transparent design with Glyph interface and clean OS.",
        image1: vacuumcleanerImage,
        image2: vacuumcleanerImage2,
        image3: vacuumcleanerImage3,
        path: "/appliances/nothing-phone-1"
      },
      {
        name: "water purifier",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: waterpurifierImage,
        image2: waterpurifierImage2,
        image3: waterpurifierImage3,
        path: "/appliances/oneplus-11"
      },
      {
        name: "electric kettle",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: electrickettleImage,
        image2: electrickettleImage2,
        image3: electrickettleImage3,
        path: "/appliances/pixel-7-pro"
      },
      {
        name: "blender",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: blenderImage,
      image2: blenderImage2,
      image3: blenderImage3,
        path: "/appliances/xiaomi-13-pro"
      },
      {
        name: "toaster",
        description: "Unique transparent design with Glyph interface and clean OS.",
        image1: toasterImage,
        image2: toasterImage2,
        image3: toasterImage3,
        path: "/appliances/nothing-phone-1"
      }
  ]

  export const TvList = [
    {
        name: "Samsung",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: samsungtvImage,
      image2: samsungtvImage2,
      image3: samsungtvImage3,
        path: "/tv/iphone-14-pro"
      },
      {
        name: "LG",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: lgtvImage,
        image2: lgtvImage2,
        image3: lgtvImage3,
        path: "/tv/galaxy-s23-ultra"
      },
      {
        name: "Sony",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: sonytvImage,
      image2: sonytvImage2,
      image3: sonytvImage3,
        path: "/tv/oneplus-11"
      },
      {
        name: "TCL",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: tcltvImage,
        image2: tcltvImage2,
        image3: tcltvImage3,
        path: "/tv/pixel-7-pro"
      },
      {
        name: "Hisense",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: hisensetvImage,
        image2: hisensetvImage2,
        image3: hisensetvImage3,
        path: "/tv/xiaomi-13-pro"
      },
      {
        name: "Vizio",
        description: "Unique transparent design with Glyph interface and clean OS.",
        image1: viziotvImage,
      image2: viziotvImage2,
      image3: viziotvImage3,
        path: "/tv/nothing-phone-1"
      },
      {
        name: "Panasonic",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: panasonictvImage,
        image2: panasonictvImage2,
        image3: panasonictvImage3,
        path: "/tv/oneplus-11"
      },
      {
        name: "Xiaomi",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: xiaomitvImage,
        image2: xiaomitvImage2,
        image3: xiaomitvImage3,
        path: "/tv/pixel-7-pro"
      },
      {
        name: "Oneplus",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: oneplustvImage,
      image2: oneplustvImage2,
      image3: oneplustvImage3,
        path: "/tv/xiaomi-13-pro"
      },
      {
        name: "Realme",
        description: "Unique transparent design with Glyph interface and clean OS.",
        image1: realmetvImage,
        image2: realmetvImage2,
        image3: realmetvImage3,
        path: "/tv/nothing-phone-1"
      }
  ]

  export const AudioList = [
    {
        name: "Headphones",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: headPhonesImage1,
      image2: headPhonesImage2,
      image3: headPhonesImage3,
        path: "/audio/iphone-14-pro"
      },
      {
        name: "Earbuds",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: earbudsImage1,
      image2: earbudsImage2,
      image3: earbudsImage3,
        path: "/audio/galaxy-s23-ultra"
      },
      {
        name: "Bluetooth Speaker",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: bluetoothspeakerImage1,
        image2: bluetoothspeakerImage2,
        image3: bluetoothspeakerImage3,
        path: "/audio/oneplus-11"
      },
      {
        name: "Soundbar",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: soundbarImage1,
      image2: soundbarImage2,
      image3: soundbarImage3,
        path: "/audio/pixel-7-pro"
      },
      {
        name: "Home Theater System",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: hometheatersystemImage1,
      image2: hometheatersystemImage2,
      image3: hometheatersystemImage3,
        path: "/audio/xiaomi-13-pro"
      },
      
  ]

  export const MenFashionList = [
    {
        name: "Formal Shirt",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: formalshirtImage1,
        image2: formalshirtImage2,
        image3: formalshirtImage3,
        path: "/menfashion/iphone-14-pro"
      },
      {
        name: "Casual Shirt",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: casualshirtImage1,
        image2: casualshirtImage2,
        image3: casualshirtImage3,
        path: "/menfashion/galaxy-s23-ultra"
      },
      {
        name: "Blazer",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: blazerImage1,
      image2: blazerImage2,
      image3: blazerImage3,
        path: "/menfashion/oneplus-11"
      },
      {
        name: "Jeans",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: jeansImage1,
        image2: jeansImage2,
        image3: jeansImage3,
        path: "/menfashion/pixel-7-pro"
      },
      {
        name: "Sneakers",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: sneakersImage1,
        image2: sneakersImage2,
        image3: sneakersImage3,
        path: "/menfashion/xiaomi-13-pro"
      },
      
  ]

  export const WomenFashionList = [
    {
        name: "Summer Dress",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: summerDressImage1,
        image2: summerDressImage2,
        image3: summerDressImage3,
        path: "/womenfashion/iphone-14-pro"
      },
      {
        name: "Evening Gown",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: eveningGown1,
      image2: eveningGown2,
      image3: eveningGown3,
        path: "/womenfashion/galaxy-s23-ultra"
      },
      {
        name: "Tops",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: topsImage1,
        image2: topsImage2,
        image3: topsImage3,
        path: "/womenfashion/oneplus-11"
      },
      {
        name: "Skirts",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: skirtsImage1,
        image2: skirtsImage2,
        image3: skirtsImage3,
        path: "/womenfashion/pixel-7-pro"
      },
      {
        name: "Handbags",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: handbagsImage1,
      image2: handbagsImage2,
      image3: handbagsImage3,
        path: "/womenfashion/xiaomi-13-pro"
      },
      
  ]

  export const KidawearFashionList = [
    {
        name: "Boys Denim Jacket",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: boysdenimjacketImage1,
      image2: boysdenimjacketImage2,
      image3: boysdenimjacketImage3,
        path: "/kidswearfashion/iphone-14-pro"
      },
      {
        name: "Girls Party Wear",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: girlsPartywearImage1,
        image2: girlsPartywearImage2,
        image3: girlsPartywearImage3,
        path: "/kidswearfashion/galaxy-s23-ultra"
      },
      {
        name: "Toddler Rompers",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: toddlerRompersImage1,
        image2: toddlerRompersImage2,
        image3: toddlerRompersImage3,
        path: "/kidswearfashion/oneplus-11"
      },
      {
        name: "Kids Sportswear Set",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: kidssportswearset1,
      image2: kidssportswearset2,
      image3: kidssportswearset3,
        path: "/kidswearfashion/pixel-7-pro"
      },
      {
        name: "Baby Winter Coat",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: kidsWinterCoatImage1,
        image2: kidsWinterCoatImage2,
        image3: kidsWinterCoatImage3,
        path: "/kidswearfashion/xiaomi-13-pro"
      },
      {
        name: "Girls Leggings Pack",
        description: "Unique transparent design with Glyph interface and clean OS.",
        image1: girlsleggingspack1,
      image2: girlsleggingspack2,
      image3: girlsleggingspack3,
        path: "/kidswearfashion/nothing-phone-1"
      },
      
  ]

  export const BeautyList = [
    {
        name: "Lipstick Set",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: lipstickSetImage1,
        image2: lipstickSetImage2,
        image3: lipstickSetImage3,
        path: "/kitchen/iphone-14-pro"
      },
      {
        name: "Face Serum",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: faceSerumImage1,
        image2: faceSerumImage2,
        image3: faceSerumImage3,
        path: "/kitchen/galaxy-s23-ultra"
      },
      {
        name: "Mascara",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: mascaraImage1,
      image2: mascaraImage2,
      image3: mascaraImage3,
        path: "/kitchen/oneplus-11"
      },
      {
        name: "Foundation",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: foundationImage1,
      image2: foundationImage2,
      image3: foundationImage3,
        path: "/kitchen/pixel-7-pro"
      },
      {
        name: "Facial Cleanser",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: facialcleanserImage1,
      image2: facialcleanserImage2,
      image3: facialcleanserImage3,
        path: "/kitchen/xiaomi-13-pro"
      },
      
  ]

  export const KitchenList = [
    {
        name: "Blender",
        description: "Apple's latest flagship with A16 Bionic chip and Dynamic Island.",
        image1: mixerImage1,
      image2: mixerImage2,
      image3: mixerImage3,
        path: "/beauty/iphone-14-pro"
      },
      {
        name: "Nonstick Cookwear Set",
        description: "High-performance Android phone with 200MP camera and S Pen.",
        image1: nonStickCookwearSet1,
      image2: nonStickCookwearSet2,
      image3: nonStickCookwearSet3,
        path: "/beauty/galaxy-s23-ultra"
      },
      {
        name: "Air Fryer",
        description: "Fast and smooth performance with Snapdragon 8 Gen 2 processor.",
        image1: airFryerImage1,
        image2: airFryerImage2,
        image3: airFryerImage3,
        path: "/beauty/oneplus-11"
      },
      {
        name: "Coffee Maker",
        description: "Google's premium phone with best-in-class camera and AI features.",
        image1: coffeeMakerImage1,
        image2: coffeeMakerImage2,
        image3: coffeeMakerImage3,
        path: "/beauty/pixel-7-pro"
      },
      {
        name: "Knife Set",
        description: "Flagship killer with Leica camera system and ultra-fast charging.",
        image1: knifeSetImage1,
      image2: knifeSetImage2,
      image3: knifeSetImage3,
        path: "/beauty/xiaomi-13-pro"
      }
      
  ]
  export const FurnitureList = [
    {
      name: "Sofa",
      description: "Soft and comfortable",
      image1: sofaImage1,
      image2: sofaImage2,
      image3: sofaImage3,
      path: "/furniture/sofa"
    },
    {
      name: "Dining Table",
      description: "Elegant dining table for family meals",
      image1: diningTableImage1,
      image2: diningTableImage2,
      image3: diningTableImage3,
      path: "/furniture/dining-table"
    },
    {
      name: "Bed",
      description: "King size bed with storage",
      image1: bedImage1,
      image2: bedImage2,
      image3: bedImage3,
      path: "/furniture/bed"
    },
    {
      name: "Coffee Table",
      description: "Stylish coffee table for your living room",
      image1: coffeeTableImage1,
      image2: coffeeTableImage2,
      image3: coffeeTableImage3,
      path: "/furniture/coffee-table"
    },
    {
      name: "Bookshelf",
      description: "Spacious bookshelf for book lovers",
      image1: bookshelfImage1,
      image2: bookshelfImage2,
      image3: bookshelfImage3,
      path: "/furniture/bookshelf"
    }
  ];
  export const FitnessList = [
    {
      name: "Treadmill",
      description: "High-performance treadmill for cardio workouts",
      image1: treadmillImage1,
      image2: treadmillImage2,
      image3: treadmillImage3,
      path: "/fitness/treadmill"
    },
    {
      name: "Dumbbells Set",
      description: "Adjustable dumbbells for strength training",
      image1: dumbellssetImage1,
      image2: dumbellssetImage2,
      image3: dumbellssetImage3,
      path: "/fitness/dumbbells-set"
    },
    {
      name: "Exercise Bike",
      description: "Indoor cycling bike for endurance and fat burn",
      image1: exercisebikeImage1,
      image2: exercisebikeImage2,
      image3: exercisebikeImage3,
      path: "/fitness/exercise-bike"
    },
    {
      name: "Yoga Mat",
      description: "Comfortable non-slip yoga mat for all practices",
      image1: yogamatImage1,
      image2: yogamatImage2,
      image3: yogamatImage3,
      path: "/fitness/yoga-mat"
    },
    {
      name: "Resistance Bands",
      description: "Durable resistance bands for full-body workouts",
      image1: resistancebandImage1,
      image2: resistancebandImage2,
      image3: resistancebandImage3,
      path: "/fitness/resistance-bands"
    },
    
  ];
  export const BooksList = [
    
    {
      name: "To Kill a Mockingbird",
      description: "Harper Lee's timeless story of justice and morality.",
      image1: toKillaMockingbirdBookImage1,
      image2: toKillaMockingbirdBookImage2,
      image3: toKillaMockingbirdBookImage3,
      path: "/books/to-kill-a-mockingbird"
    },
    {
      name: "1984",
      description: "George Orwell's chilling dystopia about surveillance and control.",
      image1:bookImage1,
      image2:bookImage2,
      image3:bookImage3,
      path: "/books/1984"
    },
    {
      name: "Pride and Prejudice",
      description: "Jane Austen's romantic novel about manners and marriage.",
      image1: prideandprejudiceImage1,
      image2: prideandprejudiceImage2,
      image3: prideandprejudiceImage3,
      path: "/books/pride-and-prejudice"
    },
    {
      name: "Moby-Dick",
      description: "Herman Melville's adventurous quest for the white whale.",
      image1: mobydickImage1,
      image2: mobydickImage2,
      image3: mobydickImage3,
      path: "/books/moby-dick"
    },
    
  ];
  export const GamingList = [
    {
      name: "PlayStation 5",
      description: "Next-gen gaming console with stunning graphics.",
      image: gamingImage,
      path: "/gaming/playstation-5"
    },
    {
      name: "Xbox Series X",
      description: "Powerful console by Microsoft for immersive gaming experiences.",
      image: gamingImage,
      path: "/gaming/xbox-series-x"
    },
    {
      name: "Nintendo Switch",
      description: "Portable and versatile gaming console from Nintendo.",
      image: gamingImage,
      path: "/gaming/nintendo-switch"
    },
    {
      name: "Steam Deck",
      description: "Handheld gaming PC from Valve for on-the-go play.",
      image: gamingImage,
      path: "/gaming/steam-deck"
    },
    {
      name: "Alienware Aurora R13",
      description: "High-performance gaming desktop for serious gamers.",
      image: gamingImage,
      path: "/gaming/alienware-aurora-r13"
    },
    {
      name: "Asus ROG Strix G15",
      description: "Gaming laptop designed for speed and power.",
      image: gamingImage,
      path: "/gaming/asus-rog-strix-g15"
    },
    {
      name: "Logitech G502 Hero",
      description: "Advanced gaming mouse with customizable options.",
      image: gamingImage,
      path: "/gaming/logitech-g502-hero"
    },
    {
      name: "Razer BlackWidow V3",
      description: "Mechanical gaming keyboard with RGB lighting.",
      image: gamingImage,
      path: "/gaming/razer-blackwidow-v3"
    },
    {
      name: "Sony DualSense Controller",
      description: "Innovative PlayStation 5 controller with adaptive triggers.",
      image: gamingImage,
      path: "/gaming/sony-dualsense-controller"
    },
    {
      name: "HyperX Cloud II",
      description: "Comfortable gaming headset with great sound quality.",
      image: gamingImage,
      path: "/gaming/hyperx-cloud-ii"
    },
    {
      name: "MSI Optix MAG274QRF",
      description: "Fast-response gaming monitor with high refresh rate.",
      image: gamingImage,
      path: "/gaming/msi-optix-mag274qrf"
    },
    {
      name: "Oculus Quest 2",
      description: "Standalone VR headset for an immersive experience.",
      image: gamingImage,
      path: "/gaming/oculus-quest-2"
    },
    {
      name: "Corsair Vengeance i7200",
      description: "Powerful gaming PC for 4K gaming and streaming.",
      image: gamingImage,
      path: "/gaming/corsair-vengeance-i7200"
    },
    {
      name: "Acer Predator Helios 300",
      description: "High-performance gaming laptop for competitive play.",
      image: gamingImage,
      path: "/gaming/acer-predator-helios-300"
    },
    {
      name: "Elgato Stream Deck",
      description: "Controller for streamers to manage live broadcasts easily.",
      image: gamingImage,
      path: "/gaming/elgato-stream-deck"
    },
    {
      name: "SteelSeries Arctis 7",
      description: "Wireless gaming headset with superior sound and comfort.",
      image: gamingImage,
      path: "/gaming/steelseries-arctis-7"
    }
  ];
  export const AutomobileList = [
    {
      name: "Tesla Model S",
      description: "Luxury electric sedan with autopilot capabilities.",
      image: automobileImage,
      path: "/automobile/tesla-model-s"
    },
    {
      name: "Ford Mustang",
      description: "Iconic American muscle car known for its performance.",
      image: automobileImage,
      path: "/automobile/ford-mustang"
    },
    {
      name: "Chevrolet Corvette",
      description: "High-performance sports car with stunning design.",
      image: automobileImage,
      path: "/automobile/chevrolet-corvette"
    },
    {
      name: "BMW X5",
      description: "Luxury SUV offering comfort and sporty driving.",
      image: automobileImage,
      path: "/automobile/bmw-x5"
    },
    {
      name: "Audi A6",
      description: "Premium sedan blending technology and performance.",
      image: automobileImage,
      path: "/automobile/audi-a6"
    },
    {
      name: "Mercedes-Benz G-Class",
      description: "Luxury off-roader with timeless boxy design.",
      image: automobileImage,
      path: "/automobile/mercedes-benz-g-class"
    },
    {
      name: "Porsche 911",
      description: "Legendary sports car known for its speed and handling.",
      image: automobileImage,
      path: "/automobile/porsche-911"
    },
    {
      name: "Toyota Camry",
      description: "Reliable and fuel-efficient family sedan.",
      image: automobileImage,
      path: "/automobile/toyota-camry"
    },
    {
      name: "Honda Civic",
      description: "Compact car combining efficiency and style.",
      image: automobileImage,
      path: "/automobile/honda-civic"
    },
    {
      name: "Lamborghini Aventador",
      description: "Exotic supercar delivering breathtaking speed.",
      image: automobileImage,
      path: "/automobile/lamborghini-aventador"
    },
    {
      name: "Jeep Wrangler",
      description: "Rugged SUV built for off-road adventures.",
      image: automobileImage,
      path: "/automobile/jeep-wrangler"
    },
    {
      name: "Nissan GT-R",
      description: "High-performance coupe nicknamed 'Godzilla'.",
      image: automobileImage,
      path: "/automobile/nissan-gt-r"
    },
    {
      name: "Range Rover Evoque",
      description: "Compact luxury SUV with off-road capabilities.",
      image: automobileImage,
      path: "/automobile/range-rover-evoque"
    },
    {
      name: "Ferrari 488",
      description: "Italian supercar offering exceptional speed and design.",
      image: automobileImage,
      path: "/automobile/ferrari-488"
    },
    {
      name: "Volkswagen Golf GTI",
      description: "Sporty hatchback known for its fun driving dynamics.",
      image: automobileImage,
      path: "/automobile/volkswagen-golf-gti"
    },
]
export const GroceriesList = [
    {
      name: "Apples",
      description: "Fresh and juicy apples.",
      image: groceriesImage,
      path: "/groceries/apples"
    },
    {
      name: "Bananas",
      description: "Ripe and sweet bananas for a healthy snack.",
      image: groceriesImage,
      path: "/groceries/bananas"
    },
    {
      name: "Carrots",
      description: "Crunchy carrots rich in vitamins.",
      image: groceriesImage,
      path: "/groceries/carrots"
    },
    {
      name: "Broccoli",
      description: "Fresh broccoli packed with nutrients.",
      image: groceriesImage,
      path: "/groceries/broccoli"
    },
    {
      name: "Potatoes",
      description: "Versatile and essential for many dishes.",
      image: groceriesImage,
      path: "/groceries/potatoes"
    },
    {
      name: "Tomatoes",
      description: "Juicy red tomatoes, perfect for salads.",
      image: groceriesImage,
      path: "/groceries/tomatoes"
    },
    {
      name: "Spinach",
      description: "Fresh spinach leaves full of iron.",
      image: groceriesImage,
      path: "/groceries/spinach"
    },
    {
      name: "Milk",
      description: "Rich and creamy dairy milk.",
      image: groceriesImage,
      path: "/groceries/milk"
    },
    {
      name: "Eggs",
      description: "Farm-fresh eggs packed with protein.",
      image: groceriesImage,
      path: "/groceries/eggs"
    },
    {
      name: "Bread",
      description: "Soft and freshly baked bread loaves.",
      image: groceriesImage,
      path: "/groceries/bread"
    },
    {
      name: "Cheese",
      description: "Delicious and creamy cheese varieties.",
      image: groceriesImage,
      path: "/groceries/cheese"
    },
    {
      name: "Rice",
      description: "Premium quality rice for everyday meals.",
      image: groceriesImage,
      path: "/groceries/rice"
    },
    {
      name: "Chicken",
      description: "Fresh and tender chicken cuts.",
      image: groceriesImage,
      path: "/groceries/chicken"
    },
    {
      name: "Yogurt",
      description: "Smooth and flavorful yogurt options.",
      image: groceriesImage,
      path: "/groceries/yogurt"
    },
    {
      name: "Oranges",
      description: "Citrusy and refreshing oranges.",
      image: groceriesImage,
      path: "/groceries/oranges"
    },
    {
      name: "Cucumbers",
      description: "Cool and crisp cucumbers for salads.",
      image: groceriesImage,
      path: "/groceries/cucumbers"
    }
  ];
  export const PetList = [
    {
      name: "Dog Food",
      description: "Nutritious dog food for all breeds.",
      image: petImage,
      path: "/pet/dog-food"
    },
    {
      name: "Cat Food",
      description: "Tasty cat food packed with essential nutrients.",
      image: petImage,
      path: "/pet/cat-food"
    },
    {
      name: "Bird Seed",
      description: "High-quality seeds for all types of birds.",
      image: petImage,
      path: "/pet/bird-seed"
    },
    {
      name: "Dog Toys",
      description: "Fun and durable toys for dogs of all sizes.",
      image: petImage,
      path: "/pet/dog-toys"
    },
    {
      name: "Cat Toys",
      description: "Interactive toys to keep your cat engaged.",
      image: petImage,
      path: "/pet/cat-toys"
    },
    {
      name: "Fish Food",
      description: "Nutritious flakes and pellets for aquarium fish.",
      image: petImage,
      path: "/pet/fish-food"
    },
    {
      name: "Pet Beds",
      description: "Soft and cozy beds for your pets to rest.",
      image: petImage,
      path: "/pet/pet-beds"
    },
    {
      name: "Pet Carriers",
      description: "Safe and comfortable carriers for travel.",
      image: petImage,
      path: "/pet/pet-carriers"
    },
    {
      name: "Dog Leashes",
      description: "Strong and durable leashes for dogs.",
      image: petImage,
      path: "/pet/dog-leashes"
    },
    {
      name: "Cat Litter",
      description: "Odor-control cat litter for easy cleaning.",
      image: petImage,
      path: "/pet/cat-litter"
    },
    {
      name: "Aquariums",
      description: "Stylish aquariums for your aquatic pets.",
      image: petImage,
      path: "/pet/aquariums"
    },
    {
      name: "Pet Grooming Kits",
      description: "Complete grooming kits for pet care at home.",
      image: petImage,
      path: "/pet/pet-grooming-kits"
    },
    {
      name: "Dog Treats",
      description: "Healthy and tasty treats for your dog.",
      image: petImage,
      path: "/pet/dog-treats"
    },
    {
      name: "Cat Treats",
      description: "Delicious treats to reward your cat.",
      image: petImage,
      path: "/pet/cat-treats"
    },
    {
      name: "Hamster Cages",
      description: "Spacious and secure cages for hamsters.",
      image: petImage,
      path: "/pet/hamster-cages"
    },
    {
      name: "Bird Cages",
      description: "Comfortable and safe cages for birds.",
      image: petImage,
      path: "/pet/bird-cages"
    }
  ];
  export const TravelList = [
    {
      name: "Travel Backpack",
      description: "Lightweight and durable backpack perfect for trips.",
      image: travelImage,
      path: "/travel/travel-backpack"
    },
    {
      name: "Neck Pillow",
      description: "Comfortable neck pillow for long journeys.",
      image: travelImage,
      path: "/travel/neck-pillow"
    },
    {
      name: "Luggage Set",
      description: "Durable and stylish luggage set for all types of travel.",
      image: travelImage,
      path: "/travel/luggage-set"
    },
    {
      name: "Portable Charger",
      description: "Keep your devices powered on the go.",
      image: travelImage,
      path: "/travel/portable-charger"
    },
    {
      name: "Travel Toiletry Bag",
      description: "Organized storage for your toiletries and cosmetics.",
      image: travelImage,
      path: "/travel/travel-toiletry-bag"
    },
    {
      name: "Travel Adapter",
      description: "Universal adapter for charging devices worldwide.",
      image: travelImage,
      path: "/travel/travel-adapter"
    },
    {
      name: "Noise Cancelling Headphones",
      description: "Block out noise during flights and travel.",
      image: travelImage,
      path: "/travel/noise-cancelling-headphones"
    },
    {
      name: "Compression Packing Cubes",
      description: "Efficiently organize your clothes and essentials.",
      image: travelImage,
      path: "/travel/compression-packing-cubes"
    },
    {
      name: "Reusable Water Bottle",
      description: "Stay hydrated during your travels with an eco-friendly bottle.",
      image: travelImage,
      path: "/travel/reusable-water-bottle"
    },
    {
      name: "Travel Wallet",
      description: "Secure wallet for passports, cards, and documents.",
      image: travelImage,
      path: "/travel/travel-wallet"
    },
    {
      name: "First Aid Kit",
      description: "Compact kit with essential medical supplies.",
      image: travelImage,
      path: "/travel/first-aid-kit"
    },
    {
      name: "Eye Mask",
      description: "Block out light and enjoy restful sleep while traveling.",
      image: travelImage,
      path: "/travel/eye-mask"
    },
    {
      name: "Travel Blanket",
      description: "Soft and compact blanket ideal for travel.",
      image: travelImage,
      path: "/travel/travel-blanket"
    },
    {
      name: "Portable Luggage Scale",
      description: "Avoid overweight baggage fees with this handy scale.",
      image: travelImage,
      path: "/travel/portable-luggage-scale"
    },
    {
      name: "Waterproof Phone Case",
      description: "Protect your phone from water damage during adventures.",
      image: travelImage,
      path: "/travel/waterproof-phone-case"
    },
    {
      name: "Travel Organizer Pouch",
      description: "Keep your cords, chargers, and gadgets neatly organized.",
      image: travelImage,
      path: "/travel/travel-organizer-pouch"
    }
  ];
  export const DecorList = [
    {
      name: "Wall Art",
      description: "Beautiful wall art to enhance your living space.",
      image: decorImage,
      path: "/decor/wall-art"
    },
    {
      name: "Table Lamps",
      description: "Elegant table lamps to brighten up your room.",
      image: decorImage,
      path: "/decor/table-lamps"
    },
    {
      name: "Cushion Covers",
      description: "Stylish cushion covers to add comfort and color.",
      image: decorImage,
      path: "/decor/cushion-covers"
    },
    {
      name: "Area Rugs",
      description: "Soft and durable rugs to add warmth to your floors.",
      image: decorImage,
      path: "/decor/area-rugs"
    },
    {
      name: "Curtains",
      description: "Decorative curtains to complete your room's look.",
      image: decorImage,
      path: "/decor/curtains"
    },
    {
      name: "Vases",
      description: "Chic vases perfect for fresh or faux flowers.",
      image: decorImage,
      path: "/decor/vases"
    },
    {
      name: "Mirrors",
      description: "Stylish mirrors to add depth and light to any space.",
      image: decorImage,
      path: "/decor/mirrors"
    },
    {
      name: "Photo Frames",
      description: "Elegant frames to showcase your precious memories.",
      image: decorImage,
      path: "/decor/photo-frames"
    },
    {
      name: "Wall Clocks",
      description: "Decorative wall clocks that combine style and function.",
      image: decorImage,
      path: "/decor/wall-clocks"
    },
    {
      name: "Indoor Plants",
      description: "Bring freshness and nature indoors with potted plants.",
      image: decorImage,
      path: "/decor/indoor-plants"
    },
    {
      name: "Candles & Holders",
      description: "Add warmth and fragrance with decorative candles.",
      image: decorImage,
      path: "/decor/candles-and-holders"
    },
    {
      name: "Bookshelves",
      description: "Modern bookshelves to organize and display your collection.",
      image: decorImage,
      path: "/decor/bookshelves"
    },
    {
      name: "Accent Chairs",
      description: "Stylish accent chairs to complement your interiors.",
      image: decorImage,
      path: "/decor/accent-chairs"
    },
    {
      name: "Wall Stickers",
      description: "Easy-to-apply wall stickers for quick decoration.",
      image: decorImage,
      path: "/decor/wall-stickers"
    },
    {
      name: "Chandeliers",
      description: "Luxurious chandeliers to elevate your home's charm.",
      image: decorImage,
      path: "/decor/chandeliers"
    },
    {
      name: "Ottomans",
      description: "Functional and stylish ottomans for seating and storage.",
      image: decorImage,
      path: "/decor/ottomans"
    }
  ];
  export const AccessoriesList = [
    {
      name: "iPhone 14 Pro Case",
      description: "Protective and stylish case for the iPhone 14 Pro.",
      image: accessoriesImage,
      path: "/accessories/iphone-14-pro"
    },
    {
      name: "Wireless Earbuds",
      description: "Premium wireless earbuds for exceptional sound quality.",
      image: accessoriesImage,
      path: "/accessories/wireless-earbuds"
    },
    {
      name: "Apple Watch Band",
      description: "Sleek and comfortable bands for your Apple Watch.",
      image: accessoriesImage,
      path: "/accessories/apple-watch-band"
    },
    {
      name: "Phone Charger Cable",
      description: "Fast charging USB-C cable for quick power-ups.",
      image: accessoriesImage,
      path: "/accessories/phone-charger-cable"
    },
    {
      name: "Portable Power Bank",
      description: "Compact power bank for charging your devices on the go.",
      image: accessoriesImage,
      path: "/accessories/portable-power-bank"
    },
    {
      name: "Bluetooth Speaker",
      description: "High-quality Bluetooth speaker for rich, portable sound.",
      image: accessoriesImage,
      path: "/accessories/bluetooth-speaker"
    },
    {
      name: "Smartphone Stand",
      description: "Ergonomic stand for your phone to view content comfortably.",
      image: accessoriesImage,
      path: "/accessories/smartphone-stand"
    },
    {
      name: "Wireless Charging Pad",
      description: "Efficient wireless charging pad for your phone and accessories.",
      image: accessoriesImage,
      path: "/accessories/wireless-charging-pad"
    },
    {
      name: "Phone Lens Kit",
      description: "Enhance your smartphone photography with lens attachments.",
      image: accessoriesImage,
      path: "/accessories/phone-lens-kit"
    },
    {
      name: "Laptop Sleeve",
      description: "Stylish and protective sleeve for your laptop.",
      image: accessoriesImage,
      path: "/accessories/laptop-sleeve"
    },
    {
      name: "Smartphone Cleaning Kit",
      description: "Complete cleaning kit for your smartphone and accessories.",
      image: accessoriesImage,
      path: "/accessories/smartphone-cleaning-kit"
    },
    {
      name: "Car Phone Mount",
      description: "Secure and adjustable mount for your phone in the car.",
      image: accessoriesImage,
      path: "/accessories/car-phone-mount"
    },
    {
      name: "Screen Protector",
      description: "Durable and scratch-resistant screen protector for your device.",
      image: accessoriesImage,
      path: "/accessories/screen-protector"
    },
    {
      name: "Smartphone Wallet Case",
      description: "All-in-one case that holds your phone and cards.",
      image: accessoriesImage,
      path: "/accessories/smartphone-wallet-case"
    },
    {
      name: "USB Flash Drive",
      description: "Portable storage solution for transferring files quickly.",
      image: accessoriesImage,
      path: "/accessories/usb-flash-drive"
    },
    {
      name: "Gaming Controller",
      description: "Wireless gaming controller for a seamless gaming experience.",
      image: accessoriesImage,
      path: "/accessories/gaming-controller"
    }
  ];
  